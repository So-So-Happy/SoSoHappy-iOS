//
//  Model.swift
//  SoSoHappy
//
//  Created by 박희경 on 2023/09/10.
//

import Foundation
