//
//  ResignResponse.swift
//  SoSoHappy
//
//  Created by 박희경 on 2023/09/14.
//

import Foundation

struct ResignResponse: Codable {
    let email: String
    let success: Bool
}
