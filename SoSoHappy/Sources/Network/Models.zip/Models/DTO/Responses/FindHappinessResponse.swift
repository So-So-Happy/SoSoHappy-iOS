//
//  FindMonthHappiness.swift
//  SoSoHappy
//
//  Created by 박희경 on 2023/09/30.
//

import Foundation

struct FindHappinessResponse: Decodable {
    let happiness: Double
    let fomattedDate: String
    
}
