//
//  File.swift
//  SoSoHappy
//
//  Created by 박희경 on 2023/09/13.
//

import Foundation

struct SetProfileResponse: Codable {
    let email: String
    let success: Bool
}
