//
//  UpdateLikeResponse.swift
//  SoSoHappy
//
//  Created by 박희경 on 2023/09/30.
//

import Foundation

struct UpdateLikeResponse: Codable {
    let like: Bool
    
}
